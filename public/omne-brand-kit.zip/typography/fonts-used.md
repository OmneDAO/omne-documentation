# Typography

| Role | Primary (paid) | Free fallback (Google Fonts) | License |
|---|---|---|---|
| Display / headline | GT Sectra Display | Cormorant Garamond | Paid (Grilli Type) / SIL OFL |
| Body | Inter | Inter | SIL OFL (free) |
| Monospace / data | JetBrains Mono | JetBrains Mono | Apache 2.0 (free) |

All shipped SVG source files use the free-fallback fonts by default. To upgrade to the paid primary, swap `font-family` in source SVGs.

Font files are NOT included in this bundle — they must be loaded via Google Fonts (free fallbacks) or licensed directly from Grilli Type (GT Sectra).

## Typographic scale

| Level | Typeface | Size (desktop) | Line height | Tracking |
|---|---|---|---|---|
| H1 | Cormorant Garamond 500 | 4rem (64px) | 1.05 | -0.02em |
| H2 | Cormorant Garamond 500 | 2.5rem (40px) | 1.1 | -0.01em |
| H3 | Cormorant Garamond 400 | 1.75rem (28px) | 1.2 | 0em |
| Body | Inter 400 | 1rem (16px) | 1.6 | 0em |
| Small | Inter 400 | 0.875rem (14px) | 1.5 | 0em |
| Caption | Inter 500 | 0.75rem (12px) | 1.4 | 0.02em |
| Code | JetBrains Mono 400 | 0.9375rem (15px) | 1.5 | 0em |
