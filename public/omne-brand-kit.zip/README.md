# Omne Brand Kit

Official brand assets for the Omne protocol. Use these when presenting Omne in press, decks, partner materials, or third-party integrations.

For full brand guidelines and design rationale, see [`docs/design/brand-id-spec.md`](../brand-id-spec.md) in the Omne repository.

---

## What's included

### Logo files (`source/`)

| File | Format | Use |
|---|---|---|
| `omne-logo.svg` (shipped at `omne-foundation/public/omne-logo.svg`) | SVG, flat ink `#0A0A0A` on transparent | Primary mark — body, navigation, favicons, light-mode contexts |
| `omne-logo-gradient.svg` | SVG, vertical gradient ink→stone | Hero treatments, press covers, banner applications only — NOT for small sizes |
| `omne-mark-simple.svg` | SVG, trace-smoothed for small sizes | Small-size rendering (≤48px) if the primary loses legibility |
| `omne-wordmark.svg` | SVG, typographic-only | Text-heavy editorial contexts where the symbol would read as decoration |
| `omne-lockup.svg` | SVG, mark + wordmark | Most day-to-day usage — signs, slides, partner lockups |
| `og-default.svg` | SVG source for link-preview card (1200×630) | Rendered to PNG and shipped as `og-default.png`; fork for route-specific OG |
| `og-per-route-template.svg` | SVG template | Duplicate + edit to produce per-route OG cards (see comments inside the file) |
| `blog-header-template.svg` | SVG template, 1600×800 | Duplicate + edit for new blog-post headers |

### Rendered assets (`omne-foundation/public/`)

| File | Dimensions | Purpose |
|---|---|---|
| `favicon.ico` | Multi-res 16/32/48 | Browser tabs |
| `favicon-16.png` | 16×16 | PNG fallback for browsers preferring PNG |
| `favicon-32.png` | 32×32 | PNG fallback |
| `apple-touch-icon.png` | 180×180 | iOS home-screen icon |
| `android-chrome-192.png` | 192×192 | Android home-screen / PWA |
| `android-chrome-512.png` | 512×512 | Android home-screen / PWA (high-res) |
| `og-default.png` | 1200×630 | Default OpenGraph / Twitter card |
| `omne-logo.svg` | Scalable | Primary mark (also served directly to browsers that support SVG favicons) |

---

## Color palette

| Token | Hex | Use |
|---|---|---|
| Ink | `#0A0A0A` | Primary fill / body text |
| Paper | `#FAFAF7` | Primary background (light mode); mark fill on dark |
| Obsidian | `#121417` | Dark-surface background |
| Silver | `#A4A6AB` | Secondary text / captions |
| Stone-500 | `#8A8A85` | Tertiary text |
| Stone-300 | `#D4D4D0` | Dividers, rule lines |
| Ignis ember | `#E8763A` | Accent — live-status, active-CTA, category tags. Used sparingly; never as body text on paper |

---

## Typography

| Role | Primary (paid) | Free fallback |
|---|---|---|
| Display / headline | GT Sectra Display | Cormorant Garamond (Google Fonts) |
| Body | Inter | Inter (Google Fonts) |
| Monospace / data | JetBrains Mono | JetBrains Mono (Google Fonts) |

All SVG source files use the free-fallback fonts by default. Swap `font-family` to upgrade once GT Sectra is licensed.

---

## Usage rules

1. Do not recolor the mark — the gradient is the gradient, the ink is the ink.
2. Do not crop the mark — every element must be fully present.
3. Do not compose the mark with other logos into a "handshake" — keep partner marks separate.
4. Do not use the mark as a background texture — it is a seal, not a wallpaper.
5. Do not substitute "cleaned up" versions — if the current mark doesn't fit, use a sanctioned sub-variant (simplified, wordmark, lockup).

See [`docs/design/brand-id-spec.md`](../brand-id-spec.md) Section 8 for the full list of cardinal sins.

---

## Regenerating assets from source

```bash
# Favicon sizes
rsvg-convert -w 16 -h 16 -b white omne-logo.svg -o favicon-16.png
rsvg-convert -w 32 -h 32 -b white omne-logo.svg -o favicon-32.png
rsvg-convert -w 48 -h 48 -b white omne-logo.svg -o favicon-48.png
magick favicon-16.png favicon-32.png favicon-48.png favicon.ico

# Apple touch icon / Android Chrome (paper mark on Obsidian)
sed 's/fill="#0A0A0A"/fill="#FAFAF7"/g' omne-logo.svg > omne-logo-paper.svg
rsvg-convert -w 140 -h 140 omne-logo-paper.svg -o mark-paper-140.png
magick -size 180x180 canvas:'#121417' mark-paper-140.png -gravity center -composite apple-touch-icon.png

# OG image
rsvg-convert -w 1200 -h 630 og-default.svg -o og-default.png

# Blog post header
rsvg-convert -w 1600 -h 800 blog-header-<slug>.svg -o blog-header-<slug>.png
```

Requires: `librsvg` (`rsvg-convert`) and `ImageMagick` (`magick` / `convert`) available via Homebrew (`brew install librsvg imagemagick`).

---

## Contact

Brand inquiries, partner lockup requests, licensing questions — [`press@omne.foundation`](mailto:press@omne.foundation).

Version: 1.0 · Last updated: 2026-04-23
